# Hidden Channels Viewer (v0.1 — NOT yet built or tested on a device)

Source: plugins/hidden-channels/ (manifest.json + js/index.ts + js/core.ts)
- Read-only. No token, no network calls, no auto-update. Cannot read channel messages.
- Shows only channels that Discord already sent to YOUR app for servers YOU are in.
- If Discord does not send them to the mobile app, the plugin says so (no workaround attempted).

Build/publish: follow README.md of this template (GitHub Actions -> Pages -> add the index.json URL
in Discord: Settings > Valenced > Plugins > Repository). The READ_PACKAGES_TOKEN is a GitHub token with
read:packages only (to download Valenced's API package), not a Discord token.
